﻿
#include <iostream>
#include "id_string.h"
#include "decimal_string.h"
int main()
{
    id_string ids("***");
    return 0;
}